# Giveaway landing page: hand-off for Aditya

**Status: DRAFT.** Do not publish until the client says so. The client and their legal reviewer review the text first. Copy the prize wording exactly as written and
do not add details about the prize anywhere (page, meta, image alt, emails). Travel dates are not published
either: they are agreed with the winner after selection, so don't add dates, a season or a year. The only time limit on the page is the 12 months to use
the prize (with Vuelitos's discretion to extend); keep it as written.

## What's in this folder

| File | What it is |
|---|---|
| `page.json` | Every admin field, Spanish (`es`) and English (`en`) |
| `body-es.html`, `body-en.html` | Content (Main Body) → HTML Source. Starts at H2; the site renders the title as H1 |
| `form/giveaway-form.es.html`, `.en.html` | The entry form: one self-contained snippet per language (CSS + HTML + JS, no libraries, ~20 KB) |
| `images/` | Three body photos (seat, meal, VIP lounge), real photos under CC licenses, credited in the body |
| `preview/` | How the page should look, desktop and 390 px, both languages |
| `src/` | Generator (`node src/build.mjs`). Monthly changes live only in `src/edition.mjs` |

## 0. It's a monthly series

One business class ticket is given away every month (edition 1 = November 2026). Keep the **same page
and permalinks** every month. Each month we send you regenerated `body-*.html`, `page.json` and form
files: only the edition number, dates and the `source` value change. The endpoint stores `source` with
each entry so editions stay apart, and closes (410) after each edition's closing time.

## 1. The page (admin → Create Static Page)

- **Show Search Bar (Service Page Mode): OFF.** This is not a route page.
- Title, permalink, hero subtitle, meta title/description, categories, tags, FAQ: from `page.json`
  (`es` block, then switch to EN for the `en` block). Permalinks: `/giveaway-espana` and `/spain-giveaway`.
- Hero and card cover: the Madrid photo you already have from the Caracas–Madrid service page
  (`hero-caracas-madrid-1600.webp` / `cover-caracas-madrid-1200x630.webp`). The photo credit is the last
  line of each body; keep it.
- Body photos: upload the three files in `images/` (seat, meal, VIP lounge; 1200×900 WebP) to the site's
  media storage and replace the `images/` prefix in each `<img src>` with their URLs. Keep the credit line at
  the end of the body: the licenses (CC BY / CC BY-SA) require it.
- Body: paste `body-<lang>.html`. It contains `<div id="vuelitos-giveaway-form">…</div>` where the form goes.
- Anchors used by the form's links: ES `#reglas`, `#privacidad`; EN `#rules`, `#privacy`. Keep the `id`s.
- The page must keep the site header, menu and footer like every other static page.

## 2. The form

The form needs its `<script>` to run. If the HTML Source content is rendered with `innerHTML` /
`dangerouslySetInnerHTML`, scripts inside it **do not execute**. Pick one:

- **A (recommended):** render the form from the site code on this page: a small component that outputs
  the snippet's markup + CSS and runs its script, mounted on `#vuelitos-giveaway-form`. The snippet is the
  spec; keep labels, validation messages, field names and checkbox wording exactly.
- **B:** if the admin can output raw HTML with scripts on a page, paste the whole snippet in place of the
  mount `<div>`.

Without JS the form still validates in the browser and posts as `application/x-www-form-urlencoded` to
its `action`. Either accept that format too, or don't render the form until the script has loaded.

**Before publishing, set the endpoint in two places** in each snippet: `var ENDPOINT = '…'` in the script
and `action="…"` on the `<form>`. While it is the placeholder, the form refuses to submit and shows "not
connected yet", so a forgotten endpoint never fakes a success.

### What the form sends (POST, `Content-Type: application/json`)

```json
{
  "full_name": "string, 3-120",       "email": "lowercased",           "phone": "+ and 8-15 digits",
  "instagram": "handle, no @, lowercased, [a-z0-9._]{1,30}",           "country": "string, ≤80",
  "referral_code": "uppercased, ≤40",  "answer": "80-1200 characters",
  "steps": { "follow": true, "like": true, "story_share": true },
  "age_confirmed": true, "rules_accepted": true, "marketing_opt_in": true,
  "consent_version": "giveaway-2026-espana-v2", "source": "giveaway-ejecutiva-01", "lang": "es|en",
  "page_url": "…", "utm": { "utm_source": "…" }, "form_started_at": "ISO time",
  "website": ""
}
```

### What the form expects back

| Status | Meaning | Form shows |
|---|---|---|
| 200 / 201 | Saved | Thank-you message |
| 409 | Same email or Instagram handle already entered | "One entry per person" |
| 410 | Giveaway closed | "The giveaway has closed" |
| 422 + `{"errors": {"email": "message"}}` | Server validation failed | Message under each field |
| 429 | Rate limited | "Wait a few minutes" |
| anything else / network | Error | "Try again in a few minutes" |

## 3. Where the form posts: two options (the client decides)

**Option 1: your backend.** `POST /api/giveaway/entries` on the website's own API. Same origin, so no
CORS. Store entries in their own table and give us an export (CSV or JSON) or a daily push so the
entries reach our contact database (every entrant has agreed to join the email and WhatsApp list).

**Option 2: a small endpoint on our side.** We would run it next to our contact database, which saves
leads with source "giveaway" and keeps the marketing consent flag. It needs a new public hostname, which
needs the client's approval. It would need **CORS** limited to `https://vuelitos.com` and
`https://www.vuelitos.com`, methods `POST, OPTIONS`, header `Content-Type`, no cookies. Nothing is
built yet. If the client picks this, we send you the URL and you only set `ENDPOINT`.

### Either way, the endpoint must

- **Validate everything again on the server.** Same rules as above; reject what doesn't match with 422.
  All six checkboxes must be `true`, including `marketing_opt_in`: joining the email and WhatsApp list
  is a condition of entry. Store the consent with `consent_version` and the time, and honour unsubscribes.
- **Spam:** if `website` (honeypot) is not empty, answer 201 and discard. Discard entries sent less than
  3 seconds after `form_started_at`. Limit body size to 8 KB.
- **Rate limit:** for example 5 entries per IP per hour and 1 per email/handle (409 for the second).
  Add Cloudflare Turnstile only if abuse appears.
- **Dedupe** on lowercased email and on Instagram handle **within the same `source`** (one entry per
  person per monthly edition).
- **Close on time:** after the closing date and time (ET), answer 410.
- **Store** the IP and received time with each entry (the privacy notice says so). Store `answer` as
  plain text and escape it wherever it is displayed.
- **Privacy:** HTTPS only, no personal data in URLs or logs, access limited to the people judging.
  Entries are deleted after the period in the privacy notice.

## 4. Before publishing (checklist)

- [ ] The client gives the go-ahead to publish.
- [ ] Endpoint set in both snippets (script and `action`), one test entry per language, test entries deleted.
- [ ] Form errors, the 409 duplicate and the thank-you message checked on a phone.
- [ ] ES and EN pages linked as a language pair (hreflang) and in the sitemap.
- [ ] The page renders H1 and body in the initial HTML (same as the route pages).
